# -*- coding: utf-8 -*-
###################################################
# Introduce:			该脚本用来提取json文件的字段，字段间用制表符分隔，所选字段可以通过config.cfg来设定
# Function: 			提取json字段输出到多列文本
# Author:				csli10
# Version:				1.0.0
# Date:					2026.06.30
# Note:					依赖tqdm用来记录
# Modify Date:
###################################################

import json, os
from configparser import ConfigParser
from tqdm import tqdm

def getConfigExtractFieldValue():
    extracted_list = []
    config = ConfigParser()
    config.read("config.cfg", encoding="utf-8")
    for i in config.options("extract_info"):
        extracted_list.append(config["extract_info"][i])
    return extracted_list

def readFile(input_file):
    with open(input_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
        # 过滤掉空行，保留所有有内容的行
        lines = [line for line in lines if line.strip()]
    return lines

def readJson(json_content):
    json_str = json.loads(json_content.strip())
    return json_str

def extractField(json_content, extracted_list):
    json_str = readJson(json_content)
    field = []
    for extracted in extracted_list:
        field.append(json_str[extracted])
    return field


if __name__ == '__main__':
    # ================== 在这里修改输入输出路径 ==================
    input_file = r"S:\数据管理\数据处理\2工具使用中待添加ING\13提取指定字段\28132-part-00000-189272.json.txt"  # 输入文件路径
    output_file = r"S:\数据管理\数据处理\2工具使用中待添加ING\13提取指定字段\28132.txt"   # 输出文件路径
    # ==========================================================

    input_path = os.path.abspath(input_file)
    output_path = os.path.abspath(output_file)

    print(f"输入文件：{input_path}")
    print(f"输出文件：{output_path}")

    if os.path.exists(output_file):
        exit("输出文件已存在，请删除或更换")

    lines = readFile(input_file)

    extracted_list = getConfigExtractFieldValue()
    print("*************************开始提取字段*************************")

    with tqdm(total=len(lines), desc="json格式转换，并写入文件中...") as pbar:
        with open(output_file, "w", encoding="utf-8") as f:
            for line in lines:
                field = extractField(line, extracted_list)
                for i in field:
                    if i != field[-1]:
                        f.write(str(i) + "\t")
                    else:
                        f.write(str(i) + "\n")
                pbar.update(1)
    print("*************************字段提取完毕*************************")