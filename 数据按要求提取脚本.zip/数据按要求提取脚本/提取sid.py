import os

# --- 配置区域 ---
input_file = "quick_shurufa_0518_output_7.txt"  # 输入文件名
output_file = "7.txt"  # 输出文件名


# ----------------

def process_file():
    if not os.path.exists(input_file):
        print(f"❌ 错误：找不到文件 '{input_file}'，请确认文件名和路径是否正确。")
        return

    # 尝试多种常见的中文编码
    encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030']
    lines = []
    success_encoding = None

    # 1. 尝试读取文件
    for enc in encodings:
        try:
            with open(input_file, 'r', encoding=enc) as f:
                lines = f.readlines()
            success_encoding = enc
            print(f"✅ 成功使用 [{enc}] 编码读取文件。")
            break
        except UnicodeDecodeError:
            continue

    if not success_encoding:
        print("❌ 无法读取文件，请检查文件编码或是否损坏。")
        return

    # 2. 处理每一行
    count = 0
    with open(output_file, 'w', encoding='utf-8') as f_out:
        for line in lines:
            line = line.strip()
            if not line:
                continue

            # 核心逻辑：优先尝试按 Tab 分割，如果没有 Tab 再按空格分割
            # \t 代表 Tab 键，很多这种对齐的文本其实是用 Tab 隔开的
            if '\t' in line:
                parts = line.split('\t')
            else:
                # 如果是空格，split() 不带参数会自动忽略多个连续空格
                parts = line.split()

            # 取第一部分（也就是红框里的内容）
            if parts:
                f_out.write(parts[0] + "\n")
                count += 1

    print(f"🎉 处理完成！共提取 {count} 行数据。")
    print(f"💾 结果已保存到: {output_file}")


if __name__ == "__main__":
    process_file()