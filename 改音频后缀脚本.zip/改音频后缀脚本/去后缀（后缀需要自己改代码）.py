# 改脚本可以用来去掉后缀，不仅限于.wav，具体实现可以通过下列形式进行代码修改
# 对应的代码注释改就行
# 1.首先改路径（看配置文件的输入输出）
# 2.其次改要转换成的脚本后缀，例如代码第24行

# 配置文件路径
input_file = "8.txt"   # 带 .wav 的文件
output_file = "9.txt"  # 去掉后缀后的新文件

with open(input_file, "r", encoding="utf-8") as f_in, \
     open(output_file, "w", encoding="utf-8") as f_out:

    for line in f_in:
        # 去掉首尾空白，确保顶格
        line = line.strip()
        if not line:
            continue
        
        # 按第一个空白分割
        parts = line.split(maxsplit=1)
        if len(parts) == 2:
            prefix, rest = parts
            # 如果 prefix 以 .wav 结尾，就去掉它
            if prefix.endswith(".wav"):
                prefix = prefix[:-4]
            # 拼接新行
            new_line = f"{prefix} {rest}"
        else:
            # 没有空格的情况，直接去掉整行的 .wav
            if line.endswith(".wav"):
                new_line = line[:-4]
            else:
                new_line = line
        
        # 写入文件
        f_out.write(new_line + "\n")

print("处理完成！")