file_path = "ceshi.txt"
new_file = "ceshixin.txt"

with open(file_path, "r", encoding="utf-8") as f_read, \
        open(new_file, "w", encoding="utf-8") as f_write:
    for line in f_read:
        # 1. 去掉首尾所有空白，确保顶格
        line = line.strip()
        if not line:
            continue

        # 2. 按第一个空白分割（不管是空格还是制表符）
        parts = line.split(maxsplit=1)
        if len(parts) == 2:
            prefix, rest = parts
            # 3. 去掉 rest 里可能自带的 .wav（比如你现在的中文后面带的.wav）
            if rest.endswith(".wav"):
                rest = rest[:-4]
            # 4. 给 prefix 加 .wav（避免重复）
            if not prefix.endswith(".wav"):
                prefix = prefix + ".wav"
            # 5. 拼接成新行：prefix.wav + 空格 + rest
            new_line = f"{prefix} {rest}"
        else:
            # 如果只有 prefix 没有 rest，就只给 prefix 加 .wav
            if not line.endswith(".wav"):
                new_line = line + ".wav"
            else:
                new_line = line

        # 写入文件，确保顶格无多余空格
        f_write.write(new_line + "\n")

print("处理完成！结果已保存到", new_file)