# 转变成6行文本，只需要A、C两行数据（比如：不需要对话人）
# 1.我们可以直接复制表格中的文字到我们新建立的一个.txt文件中
# 2.然后通过改下面的配置文件的路径，运行脚本即可
# 3.然后把output中运行后的文本复制到工具1中的input进行保存，根据实际情况运行对应的工具脚本，运行完后去到result进行复制保存到这里

# 配置文件路径
input_file = "7.txt"   # 你的原始文件，比如图里的“1.txt”
output_file = "8.txt"

with open(input_file, "r", encoding="utf-8") as f_in, \
     open(output_file, "w", encoding="utf-8") as f_out:

    for line in f_in:
        # 去掉首尾空白
        line = line.strip()
        if not line:
            continue
        
        # 按第一个空格分割，只分割两次：文件名、数字、文本
        parts = line.split(maxsplit=2)
        if len(parts) >= 3:
            # 只保留第1列（文件名）和第3列（文本）
            new_line = f"{parts[0]} {parts[2]}"
        elif len(parts) == 2:
            # 万一只有两列，直接保留
            new_line = f"{parts[0]} {parts[1]}"
        else:
            # 格式异常的行直接原样写入
            new_line = line
        
        # 写入新文件
        f_out.write(new_line + "\n")

print(f"处理完成！结果已保存到: {output_file}")