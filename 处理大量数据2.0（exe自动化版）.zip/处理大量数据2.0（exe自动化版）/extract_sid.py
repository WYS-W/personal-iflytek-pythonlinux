import os
import sys

# --- 配置区域 ---
BATCH_SIZE = 5000  # 每处理多少行写入一次磁盘
ENCODINGS = ['utf-8', 'gbk', 'gb2312', 'gb18030']  # 尝试的编码列表


# ----------------

def detect_encoding(file_path):
    """检测文件编码"""
    for enc in ENCODINGS:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                f.readline()
            return enc
        except (UnicodeDecodeError, UnicodeError):
            continue
    return None


def process_large_file(input_file, output_file=None):
    if not os.path.exists(input_file):
        print(f"❌ 错误：找不到文件 '{input_file}'")
        return

    # 自动设置输出文件名（在原文件名后加 _clean）
    if output_file is None:
        name, ext = os.path.splitext(input_file)
        output_file = f"{name}_clean{ext}"

    # 1. 检测编码
    encoding = detect_encoding(input_file)
    if not encoding:
        print("❌ 无法识别文件编码，请检查文件是否损坏或为二进制文件。")
        return

    print(f"✅ 检测到文件编码: {encoding}")
    print(f"📂 输入: {input_file}")
    print(f"💾 输出: {output_file}")

    file_size = os.path.getsize(input_file)
    print(f"📊 大小: {file_size / (1024 * 1024):.2f} MB，开始处理...")

    total_lines = 0
    success_count = 0
    error_count = 0
    buffer = []

    try:
        with open(input_file, 'r', encoding=encoding, errors='ignore') as f_in, \
                open(output_file, 'w', encoding='utf-8') as f_out:

            for line_num, line in enumerate(f_in, 1):
                total_lines += 1

                if total_lines % 10000 == 0:
                    print(f"   ⏳ 已处理: {total_lines} 行...", end='\r')

                line = line.strip()
                if not line:
                    continue

                try:
                    if '\t' in line:
                        parts = line.split('\t', 1)
                    else:
                        parts = line.split(None, 1)

                    if parts:
                        clean_data = parts[0].strip()
                        if clean_data:
                            buffer.append(clean_data)
                            success_count += 1

                except Exception as e:
                    error_count += 1
                    if error_count <= 5:
                        print(f"\n⚠️ 第 {line_num} 行处理出错: {e}")

                if len(buffer) >= BATCH_SIZE:
                    f_out.write('\n'.join(buffer) + '\n')
                    buffer.clear()

            if buffer:
                f_out.write('\n'.join(buffer) + '\n')

    except Exception as e:
        print(f"\n❌ 严重错误: {e}")
        return

    print(f"\n\n🎉 完成！{input_file} → {output_file}")
    print(f"✅ 总计: {total_lines} 行 | ✅ 提取: {success_count} | ⚠️ 跳过: {error_count}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❌ 用法: 直接拖拽文件到 run.bat，或运行: python extract_sid.py <文件名>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) >= 3 else None
    process_large_file(input_file, output_file)