import os


def clean_file(input_path, output_path):
    """
    读取文件，去除每行后面的中文/文本内容，只保留第一列的长字符串。
    """
    if not os.path.exists(input_path):
        print(f"错误：找不到文件 {input_path}")
        return

    processed_lines = []

    try:
        # 尝试使用 utf-8 编码读取，如果报错则尝试 gbk (Windows常用)
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        except UnicodeDecodeError:
            print("检测到非 UTF-8 编码，尝试使用 GBK 编码读取...")
            with open(input_path, 'r', encoding='gbk') as f:
                lines = f.readlines()

        print(f"正在处理，共发现 {len(lines)} 行数据...")

        for line in lines:
            line = line.strip()  # 去除首尾空白符
            if not line:
                continue

            # 核心逻辑：按空白字符（空格或Tab）分割，取第一个元素
            # split() 不带参数默认会处理多个连续空格
            parts = line.split()

            if parts:
                # 将第一部分（长串英文）加入列表
                processed_lines.append(parts[0])

        # 写入新文件
        with open(output_path, 'w', encoding='utf-8') as f:
            for item in processed_lines:
                f.write(item + '\n')

        print(f"处理完成！结果已保存到: {output_path}")
        print(f"共保留了 {len(processed_lines)} 条数据。")

    except Exception as e:
        print(f"发生未知错误: {e}")


if __name__ == "__main__":
    # === 在这里修改你的文件名 ===
    input_filename = '9.txt'  # 你的原始文件名
    output_filename = 'output_yuzhu.txt'  # 处理后的文件名

    # 执行清理
    clean_file(input_filename, output_filename)