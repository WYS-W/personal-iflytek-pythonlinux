# extract_first_token.py
# 功能：提取每行第一个非空白字段（如 hsc000...），无视列数；自动清理末尾空白行
# 支持：双击运行 / 拖拽 .txt 文件

import sys
import os
import re
from tkinter import Tk, filedialog

def extract_first_token(line):
    """提取一行中第一个连续非空白字符序列（直到遇到空格/制表符/换行）"""
    # 使用正则：从行首匹配一个或多个非空白字符
    match = re.match(r'^\S+', line)
    return match.group(0) if match else None

def process_file(input_path):
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        try:
            with open(input_path, 'r', encoding='gbk') as f:
                lines = f.readlines()
        except Exception as e:
            print(f"❌ 无法读取 {input_path}：{e}")
            return False
    except Exception as e:
        print(f"❌ 读取失败：{e}")
        return False

    # 提取每行的第一个 token（非空白前缀）
    tokens = []
    for line in lines:
        token = extract_first_token(line)
        if token is not None:  # 仅保留有有效首字段的行
            tokens.append(token + '\n')

    # 清除末尾连续空行（虽然已过滤空行，但防万一）
    while tokens and tokens[-1].strip() == '':
        tokens.pop()

    # 输出路径
    dir_name, base_name = os.path.split(input_path)
    name, ext = os.path.splitext(base_name)
    output_path = os.path.join(dir_name, f"{name}_first_token{ext}")

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.writelines(tokens)
        print(f"✅ 处理完成：")
        print(f"   输入：{os.path.basename(input_path)} ({len(lines)} 行)")
        print(f"   输出：{os.path.basename(output_path)} ({len(tokens)} 行)")
        print(f"   已保存至：{output_path}")
        return True
    except Exception as e:
        print(f"❌ 写入失败：{e}")
        return False

def main():
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        if os.path.isfile(file_path) and file_path.lower().endswith('.txt'):
            process_file(file_path)
        else:
            print("⚠️ 请拖拽一个 .txt 文件到此脚本上")
    else:
        root = Tk()
        root.withdraw()
        file_path = filedialog.askopenfilename(
            title="请选择要提取首字段的 TXT 文件",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        root.destroy()
        if file_path:
            process_file(file_path)
        else:
            print("❌ 未选择文件")

if __name__ == "__main__":
    main()