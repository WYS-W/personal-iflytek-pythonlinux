import os
import sys

# --- 配置区域 ---
INPUT_FILE = "output-car.txt"  # 输入文件名
OUTPUT_FILE = "1.txt"                   # 输出文件名
BATCH_SIZE = 5000                               # 每处理多少行写入一次磁盘（减少IO次数）
ENCODINGS = ['utf-8', 'gbk', 'gb2312', 'gb18030'] # 尝试的编码列表
# ----------------

def detect_encoding(file_path):
    """检测文件编码"""
    for enc in ENCODINGS:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                f.readline()  # 尝试读取第一行
            return enc
        except (UnicodeDecodeError, UnicodeError):
            continue
    return None

def process_large_file():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误：找不到文件 '{INPUT_FILE}'")
        return

    # 1. 自动检测编码
    encoding = detect_encoding(INPUT_FILE)
    if not encoding:
        print("❌ 无法识别文件编码，请检查文件是否损坏或为二进制文件。")
        return
    
    print(f"✅ 检测到文件编码: {encoding}")
    
    # 获取文件大小用于计算进度（可选）
    file_size = os.path.getsize(INPUT_FILE)
    print(f"📂 文件大小: {file_size / (1024*1024):.2f} MB，开始处理...")

    total_lines = 0
    success_count = 0
    error_count = 0
    
    buffer = []  # 写入缓冲区

    try:
        # 2. 使用生成器模式流式读取，不占用大量内存
        with open(INPUT_FILE, 'r', encoding=encoding, errors='ignore') as f_in, \
             open(OUTPUT_FILE, 'w', encoding='utf-8') as f_out:
            
            for line_num, line in enumerate(f_in, 1):
                total_lines += 1
                
                # 打印进度（每处理1万行或文件结束时打印）
                if total_lines % 10000 == 0:
                    print(f"   ⏳ 已处理: {total_lines} 行...", end='\r')

                line = line.strip()
                if not line:
                    continue

                try:
                    # 核心分割逻辑
                    if '\t' in line:
                        parts = line.split('\t', 1) # 限制分割次数，提高性能
                    else:
                        parts = line.split(None, 1) # 按空白符分割，限制次数
                    
                    if parts:
                        # 只取第一部分，并去除首尾可能存在的空格
                        clean_data = parts[0].strip()
                        if clean_data: 
                            buffer.append(clean_data)
                            success_count += 1
                            
                except Exception as e:
                    error_count += 1
                    # 仅在控制台记录前几个错误，避免刷屏
                    if error_count <= 5:
                        print(f"\n⚠️ 第 {line_num} 行处理出错: {e}")

                # 3. 批量写入磁盘（当缓冲区满时）
                if len(buffer) >= BATCH_SIZE:
                    f_out.write('\n'.join(buffer) + '\n')
                    buffer.clear()

            # 处理剩余的数据
            if buffer:
                f_out.write('\n'.join(buffer) + '\n')

    except Exception as e:
        print(f"\n❌ 发生严重系统错误: {e}")
        return

    # 4. 最终报告
    print(f"\n\n🎉 处理完成！")
    print(f"📊 统计信息:")
    print(f"   - 总行数扫描: {total_lines}")
    print(f"   - 成功提取:   {success_count}")
    print(f"   - 跳过/错误:  {error_count}")
    print(f"💾 结果已保存至: {OUTPUT_FILE}")

if __name__ == "__main__":
    process_large_file()