# trim_trailing_blank.py
# 功能：去除文本文件末尾的连续空白行（保留中间空行）
# 使用方式：双击运行 或 拖拽 .txt 文件到此脚本图标上

import sys
import os
from tkinter import Tk, filedialog

def trim_trailing_blanks(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        # 尝试用 gbk 编码（常见于中文 Windows 系统）
        try:
            with open(file_path, 'r', encoding='gbk') as f:
                lines = f.readlines()
        except Exception as e:
            print(f"❌ 无法读取文件 {file_path}，编码错误：{e}")
            return False
    except Exception as e:
        print(f"❌ 读取失败：{e}")
        return False

    # 删除末尾连续空白行（空行或仅含空格/制表符的行）
    while lines and lines[-1].strip() == '':
        lines.pop()

    # 构造输出路径：原名 + "_clean"
    dir_name, base_name = os.path.split(file_path)
    name, ext = os.path.splitext(base_name)
    output_path = os.path.join(dir_name, f"{name}_clean{ext}")

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        print(f"✅ 成功清理：")
        print(f"   输入：{os.path.basename(file_path)} ({len([l for l in open(file_path,'r').readlines()])} 行)")
        print(f"   输出：{os.path.basename(output_path)} ({len(lines)} 行)")
        print(f"   已保存至：{output_path}")
        return True
    except Exception as e:
        print(f"❌ 写入失败：{e}")
        return False

def main():
    # 如果有拖拽参数（即传入了文件路径）
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        if os.path.isfile(file_path) and file_path.lower().endswith('.txt'):
            trim_trailing_blanks(file_path)
        else:
            print("⚠️ 请拖拽一个 .txt 文件到此脚本上")
    else:
        # 无参数时弹出文件选择对话框
        root = Tk()
        root.withdraw()  # 隐藏主窗口
        file_path = filedialog.askopenfilename(
            title="请选择要清理的 TXT 文件",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        root.destroy()
        if file_path:
            trim_trailing_blanks(file_path)
        else:
            print("❌ 未选择文件")

if __name__ == "__main__":
    main()