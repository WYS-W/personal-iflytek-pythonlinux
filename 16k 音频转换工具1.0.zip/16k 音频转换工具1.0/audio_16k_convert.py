import os
from pydub import AudioSegment

# 配置参数
target_sample_rate = 16000  # 目标采样率16000
target_channels = 1          # 单通道语音标准
target_bit_depth = 16        # 16bit位深

# 当前脚本所在文件夹
source_dir = os.getcwd()
# 输出文件夹，自动创建
output_dir = os.path.join(source_dir, "16k_wav输出")
os.makedirs(output_dir, exist_ok=True)

# 【仅此处修改：扩充小众音频后缀，其余代码无改动】
audio_suffix = (".wav", ".mp3", ".m4a", ".flac", ".ogg", ".aac",
                 ".amr", ".ape", ".wv", ".voc", ".opus", ".wma")

def convert_audio(file_path, out_path):
    """音频转换函数：统一16000Hz 单通道16bit wav"""
    try:
        # 读取原始音频
        audio = AudioSegment.from_file(file_path)
        # 转换采样率、声道、位深
        audio = audio.set_frame_rate(target_sample_rate)
        audio = audio.set_channels(target_channels)
        audio = audio.set_sample_width(target_bit_depth // 8)
        # 导出wav
        audio.export(out_path, format="wav")
        return True
    except Exception as e:
        print(f"转换失败 {os.path.basename(file_path)} : {str(e)}")
        return False

if __name__ == "__main__":
    success_count = 0
    fail_count = 0

    for filename in os.listdir(source_dir):
        # 跳过输出文件夹、脚本自身
        if filename == "16k_wav输出" or filename.endswith(".py"):
            continue
        # 筛选音频文件
        if filename.lower().endswith(audio_suffix):
            file_full_path = os.path.join(source_dir, filename)
            # 输出文件名，后缀强制改为.wav
            file_name_no_ext = os.path.splitext(filename)[0]
            output_wav_path = os.path.join(output_dir, f"{file_name_no_ext}.wav")

            # 执行转换
            res = convert_audio(file_full_path, output_wav_path)
            if res:
                success_count += 1
                print(f"✅ 已转换：{filename}")
            else:
                fail_count += 1

    print("\n===== 转换完成汇总 =====")
    print(f"成功转换文件：{success_count} 个")
    print(f"转换失败文件：{fail_count} 个")
    print(f"转换后文件存放目录：{output_dir}")