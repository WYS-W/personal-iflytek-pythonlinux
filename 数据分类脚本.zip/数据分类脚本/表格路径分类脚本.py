import pandas as pd
import os

# ==================== 🛠️ 配置区域 ====================

# 1. 输入文件（原始数据）
INPUT_FILE = 'shuru.xlsx'

# 2. 输出文件（存放整理后数据的 Excel）
OUTPUT_FILE = 'shuchu.xlsx'

# ======================================================

def main():
    # 检查输入文件是否存在
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误：找不到文件 {INPUT_FILE}，请确认文件名是否正确。")
        return

    try:
        print(f"📖 正在读取 {INPUT_FILE} ...")
        # 读取 Excel 数据
        df = pd.read_excel(INPUT_FILE)

        # 找到包含路径的列（通常是最后一列，或者叫 '地址', 'Path' 等）
        # 这里假设最后一列是路径列，如果你的列名固定，可以改为 df['你的列名']
        path_col = df.columns[-1]
        print(f"✅ 读取成功，共 {len(df)} 行数据。识别到路径列为：{path_col}")

        # --- 核心逻辑：生成用于排序的“大路径” ---
        print("🔄 正在分析路径结构并归类...")

        # 使用 os.path.dirname 提取每一行的“文件夹路径”（去掉文件名）
        # 这样 '/a/b/c/file1.txt' 和 '/a/b/c/file2.txt' 都会变成 '/a/b/c/'
        df['_sort_key'] = df[path_col].apply(lambda x: os.path.dirname(str(x)) if pd.notna(x) else "")

        # --- 执行排序 ---
        # 1. 先按 '语种' (如果有)
        # 2. 再按我们生成的 '_sort_key' (大路径)
        # 3. 最后按原路径 (让同文件夹内的文件也按字母顺序排好)

        sort_cols = []
        if '语种' in df.columns:
            sort_cols.append('语种')

        # 将大路径加入排序优先级
        sort_cols.append('_sort_key')

        # 执行排序
        df_sorted = df.sort_values(by=sort_cols, ascending=True)

        # 删除辅助用的排序列，保持表格干净
        df_sorted = df_sorted.drop(columns=['_sort_key'])

        # --- 保存结果 ---
        print(f"💾 正在保存整理好的数据到 {OUTPUT_FILE} ...")
        df_sorted.to_excel(OUTPUT_FILE, index=False)

        print("🎉 处理完成！请查看 cunfang.xlsx，现在相同大路径的数据已经聚在一起了。")

    except Exception as e:
        print(f"❌ 发生错误：{e}")

if __name__ == '__main__':
    main()