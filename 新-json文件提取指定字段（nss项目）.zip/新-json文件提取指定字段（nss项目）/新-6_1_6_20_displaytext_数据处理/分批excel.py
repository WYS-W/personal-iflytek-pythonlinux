# 六万行数据分批导出Excel（6批，每批约1万行）
# 逐行读取，三列严格对应，不窜行
import os
from openpyxl import Workbook

# ============ 路径配置 ============
INPUT_FILE = r"S:\数据管理\数据处理\4数据提取\测试\6_1_6_20_displaytext.txt"
OUTPUT_DIR = r"S:\数据管理\数据处理\4数据提取\测试\分批结果"
BATCH_SIZE = 10000   # 每批行数
# ==================================

def parse_line(line):
    """解析一行，返回 [sid, asrtext, displayText] 三列"""
    line = line.rstrip("\n").rstrip("\r")
    if not line:
        return None

    # 优先按制表符 \t 分割（最常见的数据导出格式）
    parts = line.split("\t")
    if len(parts) >= 3:
        return [parts[0], parts[1], parts[2]]

    # 退而求其次：sid 取第一段，剩下按空格再拆两段
    # （仅当制表符分割失败时启用，防止窜列）
    parts = line.split(None, 2)  # 最多拆3段
    if len(parts) == 3:
        return parts
    elif len(parts) == 2:
        return [parts[0], parts[1], ""]
    elif len(parts) == 1:
        return [parts[0], "", ""]
    return None


def split_to_excel():
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 找不到输入文件：\n{INPUT_FILE}")
        print("请检查S盘是否连通、路径是否正确")
        return

    # 创建输出目录
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 先统计总行数（跳过表头）
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        total = sum(1 for _ in f) - 1  # 减去表头
    print(f"📊 数据总行数（不含表头）：{total}")
    print(f"📦 每批 {BATCH_SIZE} 行，预计分 { (total + BATCH_SIZE - 1) // BATCH_SIZE } 批\n")

    batch_idx = 1
    row_count = 0  # 当前批已写入行数
    wb = Workbook()
    ws = wb.active
    ws.title = f"第{batch_idx}批"
    # 写表头
    ws.append(["sid", "asrtext", "displayText"])

    with open(INPUT_FILE, "r", encoding="utf-8") as fin:
        # 跳过表头行
        next(fin)

        for line in fin:
            cols = parse_line(line)
            if cols is None:
                continue

            ws.append(cols)
            row_count += 1

            # 每批满了就保存，开新文件
            if row_count >= BATCH_SIZE:
                out_path = os.path.join(OUTPUT_DIR, f"第{batch_idx}批_{row_count}行.xlsx")
                wb.save(out_path)
                print(f"✅ 第{batch_idx}批完成：{row_count}行 → {out_path}")

                batch_idx += 1
                row_count = 0
                wb = Workbook()
                ws = wb.active
                ws.title = f"第{batch_idx}批"
                ws.append(["sid", "asrtext", "displayText"])

    # 保存最后一批（不满 BATCH_SIZE 的剩余行）
    if row_count > 0:
        out_path = os.path.join(OUTPUT_DIR, f"第{batch_idx}批_{row_count}行.xlsx")
        wb.save(out_path)
        print(f"✅ 第{batch_idx}批完成：{row_count}行 → {out_path}")

    print(f"\n🎉 全部完成！共 {batch_idx} 个Excel文件，输出目录：\n{OUTPUT_DIR}")


if __name__ == "__main__":
    split_to_excel()
