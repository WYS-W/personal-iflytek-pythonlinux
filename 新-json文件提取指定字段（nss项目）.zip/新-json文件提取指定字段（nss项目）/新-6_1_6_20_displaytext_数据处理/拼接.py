# 功能：sid + [asrtext//displayText%%] 输出新txt
# 格式示例：hsc000e51ec0hf19ea496e062902 邯郸有没有一个什么船舶的什么研究所呢，编号编号的什么999或者什么之类的 根据您的描述，在邯郸有一个与船舶相关的研究所，但编号不是999。//莫兰德制造的香水有什么 您提到的“莫兰德”很可能指的是 **Molinard**，这是一个源自法国香水之都格拉斯的历史悠久的香水品牌，也被译为“慕莲勒”。%%
import os

# =====================配置路径=====================
INPUT_FILE = r"S:\数据管理\数据处理\4数据提取\测试\6_1_6_20_displaytext.txt"
OUTPUT_FILE = r"S:\数据管理\数据处理\4数据提取\测试\merged_sid_dialog.txt"
# ==================================================

def process_data():
    if not os.path.exists(INPUT_FILE):
        print("❌ 输入文件不存在，请核对路径！")
        return

    count = 0
    with open(INPUT_FILE, "r", encoding="utf-8") as fin, open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
        # 跳过表头 sid asrtext displayText
        next(fin)
        for line in fin:
            raw = line.strip()
            if not raw:
                continue
            # 最多分割3段：sid，asrtext，displayText（重点！防止文本内部空格拆分错乱）
            parts = raw.split(maxsplit=2)
            if len(parts) != 3:
                continue
            sid, asrtext, displaytext = parts
            # 拼接格式：asrtext//displaytext%%
            combine_text = f"{asrtext}//{displaytext}%%"
            # 整行：sid + 空格 + 合并文本
            output_line = f"{sid} {combine_text}\n"
            fout.write(output_line)
            count += 1
            if count % 10000 == 0:
                print(f"已处理 {count} 条")

    print(f"✅ 处理完成！总共生成 {count} 条对话")
    print(f"输出文件路径：{OUTPUT_FILE}")

if __name__ == "__main__":
    process_data()
