# 配置文件名（和你文件夹内文件名完全对应，不要修改文字）
file_old = "无-俄语-原来.txt"
file_check = "无-俄语-复查.txt"
output_file = "不重复路径汇总.txt"

def read_all_lines(file_name):
    """读取文件所有非空路径，完整保留原始文本存入集合"""
    line_set = set()
    with open(file_name, "r", encoding="utf-8") as f:
        for line in f:
            clean_line = line.strip()
            if clean_line:
                line_set.add(clean_line)
    return line_set

# 读取两份文件所有路径
set_old = read_all_lines(file_old)
set_check = read_all_lines(file_check)

# 计算两边互不重复的路径合集
only_old = set_old - set_check    # 只在原文件存在，复查没有
only_check = set_check - set_old  # 只在复查文件存在，原文件没有
all_unique = sorted(list(only_old) + list(only_check))

# 写入新文件，路径原样输出不做任何改动
with open(output_file, "w", encoding="utf-8") as out:
    for path in all_unique:
        out.write(path + "\n")

# 打印运行结果
print(f"比对完成！")
print(f"仅原文件独有路径：{len(only_old)} 条")
print(f"仅复查文件独有路径：{len(only_check)} 条")
print(f"全部不重复路径总数：{len(all_unique)} 条")
print(f"结果已自动生成文件：{output_file}")