# clean_sid.py
input_file = '28436_0716.txt'
output_file = 'cleaned_output.txt'

with open(input_file, 'r', encoding='utf-8') as fin, \
     open(output_file, 'w', encoding='utf-8') as fout:
    for line in fin:
        line = line.strip()
        if not line:
            fout.write('\n')
            continue
        parts = line.split('\t', 1)
        if len(parts) > 1:
            fout.write(parts[1] + '\n')
        else:
            fout.write('\n')  # 或写 parts[0]，根据实际数据决定

print(f"✅ 处理完成！结果已保存至：{output_file}")