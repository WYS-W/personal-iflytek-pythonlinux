import chardet
import os


def detect_encoding(file_path):
    """自动检测文件编码，防止中文乱码"""
    with open(file_path, 'rb') as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        # 如果置信度太低，默认尝试 utf-8 或 gbk
        return result['encoding'] if result['confidence'] > 0.7 else 'utf-8'


def process_file(input_file, output_file):
    print(f"正在检测文件编码: {input_file} ...")
    encoding = detect_encoding(input_file)
    print(f"检测到编码: {encoding}")

    processed_count = 0

    try:
        with open(input_file, 'r', encoding=encoding) as fin, \
                open(output_file, 'w', encoding='utf-8') as fout:

            for line in fin:
                line = line.strip()
                if not line:
                    continue

                # 核心逻辑：按空格分割，maxsplit=1 表示只切一刀
                # parts[0] 是第一列 ID
                # parts[1] 是剩下的所有内容
                parts = line.split(None, 1)

                if len(parts) >= 2:
                    col_id = parts[0]
                    rest_text = parts[1]

                    # 再次对剩下的文本按空格分割，取第一个词作为“第一句话”
                    sentence_parts = rest_text.split(None, 1)
                    first_sentence = sentence_parts[0]

                    # 写入结果：ID + 制表符 + 第一句话
                    fout.write(f"{col_id}\t{first_sentence}\n")
                    processed_count += 1
                else:
                    # 如果这一行没有空格（只有ID），直接跳过或按需处理
                    pass

        print(f"处理完成！共处理 {processed_count} 行。")
        print(f"结果已保存到: {output_file}")

    except Exception as e:
        print(f"发生错误: {e}")


if __name__ == "__main__":
    # === 在这里修改你的文件名 ===
    input_filename = 'quick_shurufa_0518_output_7.txt'  # 你的原始文件名
    output_filename = 'quick_shurufa_0518_output_7_只保留一句话.txt'  # 输出文件名

    if os.path.exists(input_filename):
        process_file(input_filename, output_filename)
    else:
        print(f"找不到文件: {input_filename}，请确保文件在当前目录下。")