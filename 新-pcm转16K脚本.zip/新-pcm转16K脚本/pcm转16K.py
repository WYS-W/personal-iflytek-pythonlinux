import os
import wave
from pathlib import Path

# ============================================================
# ⚙️ PCM 参数配置 - 请根据实际源文件规格修改！
# ============================================================
PCM_CONFIG = {
    "sample_rate": 16000,   # 采样率 (Hz)
    "channels": 1,          # 声道数: 1=单声道, 2=立体声
    "sampwidth": 2,         # 位深(字节): 2=16bit, 3=24bit, 4=32bit
}

# 父级目录（包含多个子文件夹的路径）
PARENT_DIR = r"S:\有监督\英文\业务\2024_2026\2026年\20260811_英文短语音问题单质检"
# ============================================================


def pcm_to_wav(pcm_path: str, wav_path: str, config: dict):
    """将单个 Raw PCM 文件转换为 WAV 文件"""
    with open(pcm_path, 'rb') as pcm_file:
        raw_data = pcm_file.read()
    with wave.open(wav_path, 'wb') as wav_file:
        wav_file.setnchannels(config["channels"])
        wav_file.setsampwidth(config["sampwidth"])
        wav_file.setframerate(config["sample_rate"])
        wav_file.writeframes(raw_data)


def select_folder(parent_dir: str) -> Path | None:
    """交互式选择子文件夹"""
    parent = Path(parent_dir)
    if not parent.exists():
        print(f"❌ 父级目录不存在: {parent_dir}")
        return None

    # 获取所有子文件夹并排序
    subdirs = sorted([d for d in parent.iterdir() if d.is_dir()], key=lambda x: x.name)

    if not subdirs:
        print(f"⚠️ 该目录下没有子文件夹: {parent_dir}")
        return None

    print("=" * 60)
    print("📂 请选择要转换的文件夹:")
    print("=" * 60)
    for idx, folder in enumerate(subdirs, 1):
        # 统计该文件夹下 .pcm 文件数量
        pcm_count = len(list(folder.glob("*.pcm")))
        print(f"  [{idx}] {folder.name}  ({pcm_count} 个 .pcm 文件)")
    print("=" * 60)

    while True:
        choice = input("\n请输入编号 (或输入 q 退出): ").strip()
        if choice.lower() == 'q':
            print("👋 已退出")
            return None
        try:
            idx = int(choice)
            if 1 <= idx <= len(subdirs):
                selected = subdirs[idx - 1]
                print(f"\n✅ 已选择: {selected.name}\n")
                return selected
            else:
                print(f"⚠️ 请输入 1~{len(subdirs)} 之间的数字")
        except ValueError:
            print("⚠️ 无效输入，请输入数字编号")


def batch_convert(input_dir: Path, config: dict):
    """批量转换指定文件夹中所有 .pcm 文件"""
    output_dir = input_dir / "wav_output"
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"📁 输出文件夹: {output_dir.resolve()}\n")

    pcm_files = sorted(input_dir.glob("*.pcm"))
    if not pcm_files:
        print(f"⚠️ 未找到任何 .pcm 文件")
        return

    print(f"🔍 找到 {len(pcm_files)} 个 PCM 文件，开始转换...\n")

    success_count = 0
    for i, pcm_file in enumerate(pcm_files, 1):
        wav_filepath = output_dir / (pcm_file.stem + ".wav")
        try:
            pcm_to_wav(str(pcm_file), str(wav_filepath), config)
            size_kb = wav_filepath.stat().st_size / 1024
            print(f"  ✅ [{i}/{len(pcm_files)}] {pcm_file.name} → {wav_filepath.name} ({size_kb:.1f} KB)")
            success_count += 1
        except Exception as e:
            print(f"  ❌ [{i}/{len(pcm_files)}] {pcm_file.name} 失败: {e}")

    print(f"\n🎉 转换完成! 成功: {success_count}/{len(pcm_files)}")
    print(f"📁 WAV 文件已保存至: {output_dir.resolve()}")


if __name__ == "__main__":
    selected = select_folder(PARENT_DIR)
    if selected:
        batch_convert(selected, PCM_CONFIG)