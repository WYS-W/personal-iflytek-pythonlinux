# replace_tab.py
import sys
import os


def process_file(input_path, output_path):
    encodings = ['utf-8', 'gbk', 'gb2312', 'gb18030']
    content = None

    for enc in encodings:
        try:
            with open(input_path, 'r', encoding=enc) as f:
                content = f.readlines()
            print(f"✅ 使用编码: {enc}")
            break
        except UnicodeDecodeError:
            continue

    if content is None:
        print("❌ 无法识别文件编码，请另存为 UTF-8")
        return False

    # 处理：将 \t 替换为空格（只替换第一个 \t，保留后续空格）
    processed = []
    for line in content:
        # 去掉行尾换行符，再处理
        line = line.rstrip('\n\r')
        # 找到第一个 \t，替换为单个空格；其余 \t 也替换为单个空格（按需可改）
        if '\t' in line:
            parts = line.split('\t', 1)  # 只分割一次：[sid, rest]
            new_line = parts[0] + ' ' + parts[1].lstrip()  # sid + 空格 + 话语（去开头空格）
        else:
            new_line = line  # 无 tab，保持原样
        processed.append(new_line + '\n')

    # 写入输出文件
    with open(output_path, 'w', encoding='utf-8') as f:
        f.writelines(processed)

    print(f"🎉 完成！{os.path.basename(input_path)} → {os.path.basename(output_path)}")
    print(f"✅ 总行数: {len(content)} | ✅ 处理完成")
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("📌 请将 .txt 文件拖拽到此程序上！")
        input("按回车退出...")
        sys.exit(1)

    input_file = sys.argv[1]
    if not os.path.isfile(input_file):
        print("❌ 文件不存在！")
        input("按回车退出...")
        sys.exit(1)

    if not input_file.lower().endswith('.txt'):
        print("⚠️ 仅支持 .txt 文件")
        input("按回车退出...")
        sys.exit(1)

    base, ext = os.path.splitext(input_file)
    output_file = base + '_no_tab.txt'  # 区分于之前的 _clean.txt

    try:
        process_file(input_file, output_file)
    except Exception as e:
        print(f"❌ 处理出错: {e}")

    input("按回车退出...")